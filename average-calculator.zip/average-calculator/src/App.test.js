import { render, screen } from '@testing-library/react';
import App from './App';

test('renders Average Calculator title', () => {
  render(<App />);
  const titleElement = screen.getByText(/average calculator/i);
  expect(titleElement).toBeInTheDocument();
});

test('renders input field', () => {
  render(<App />);
  const inputElement = screen.getByPlaceholderText(/enter numbers separated by commas/i);
  expect(inputElement).toBeInTheDocument();
});

test('renders calculate button', () => {
  render(<App />);
  const buttonElement = screen.getByRole('button', { name: /calculate average/i });
  expect(buttonElement).toBeInTheDocument();
});