import React, { useState } from 'react';

const AverageCalculator = () => {
    const [numbers, setNumbers] = useState('');
    const [average, setAverage] = useState(null);

    const handleInputChange = (event) => {
        setNumbers(event.target.value);
    };

    const calculateAverage = () => {
        const numArray = numbers.split(',').map(num => parseFloat(num.trim())).filter(num => !isNaN(num));
        if (numArray.length > 0) {
            const total = numArray.reduce((acc, curr) => acc + curr, 0);
            setAverage(total / numArray.length);
        } else {
            setAverage(null);
        }
    };

    return (
        <div>
            <h1>Average Calculator</h1>
            <input 
                type="text" 
                value={numbers} 
                onChange={handleInputChange} 
                placeholder="Enter numbers separated by commas" 
            />
            <button onClick={calculateAverage}>Calculate Average</button>
            {average !== null && <h2>Average: {average}</h2>}
        </div>
    );
};

export default AverageCalculator;